import React from 'react';
import {useUserProfile} from './useUserProfile.js';

export default function RoleGate({ allowedRoles, children }) {
  const { profile, loading } = useUserProfile();

  if (loading) {
    return null;
  }

  if (!profile || !allowedRoles.includes(profile.role)) {
    return (
      <div style={{ maxWidth: '760px', margin: '0 auto', padding: '24px 16px 64px', color: 'var(--text, #cdd6f4)' }}>
        <p style={{ color: 'var(--subtext, #a6adc8)', fontSize: '0.875rem', margin: '0 0 16px' }}>
          Sign in to see this page.
        </p>
      </div>
    );
  }

  return children;
}
