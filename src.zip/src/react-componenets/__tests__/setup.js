import { vi } from 'vitest';

// Mock Firebase module to avoid loading live API keys during tests
vi.mock('../firebase.js', () => ({
  auth: {
    currentUser: null,
    onAuthStateChanged: vi.fn((callback) => {
      callback(null);
      return vi.fn(); // unsubscribe mock
    }),
  },
  db: {},
}));
