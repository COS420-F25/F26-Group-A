import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import RoleGate from '../RoleGate.jsx';

// 1. Create the mock function for the hook
const mockHook = vi.fn();

// 2. Wrap it explicitly under the `default` key for Vitest ESM support
vi.mock('../useUserProfile.js', () => ({
  default: () => mockHook(),
}));

describe('RoleGate Component', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders loading state (null) while profile data is fetching', () => {
    mockHook.mockReturnValue({
      profile: null,
      loading: true,
    });

    const { container } = render(
      <RoleGate allowedRoles={['instructor']}>
        <div>Protected Content</div>
      </RoleGate>
    );

    expect(screen.queryByText('Protected Content')).not.toBeInTheDocument();
    expect(screen.queryByText('Sign in to see this page.')).not.toBeInTheDocument();
    expect(container.firstChild).toBeNull();
  });

  it('renders children when user role is included in allowedRoles', () => {
    mockHook.mockReturnValue({
      profile: { role: 'instructor' },
      loading: false,
    });

    render(
      <RoleGate allowedRoles={['instructor', 'admin']}>
        <div>Protected Content</div>
      </RoleGate>
    );

    expect(screen.getByText('Protected Content')).toBeInTheDocument();
  });

  it('denies access and shows sign-in prompt when user role is not allowed', () => {
    mockHook.mockReturnValue({
      profile: { role: 'student' },
      loading: false,
    });

    render(
      <RoleGate allowedRoles={['instructor']}>
        <div>Protected Content</div>
      </RoleGate>
    );

    expect(screen.queryByText('Protected Content')).not.toBeInTheDocument();
    expect(screen.getByText('Sign in to see this page.')).toBeInTheDocument();
  });

  it('denies access when user is not logged in (profile is null)', () => {
    mockHook.mockReturnValue({
      profile: null,
      loading: false,
    });

    render(
      <RoleGate allowedRoles={['instructor']}>
        <div>Protected Content</div>
      </RoleGate>
    );

    expect(screen.queryByText('Protected Content')).not.toBeInTheDocument();
    expect(screen.getByText('Sign in to see this page.')).toBeInTheDocument();
  });
});
